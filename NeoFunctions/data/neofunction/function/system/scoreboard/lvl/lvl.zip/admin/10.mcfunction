# 命名：10
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/admin/10


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 10
effect give @s minecraft:instant_health 1 26 true
function neofunction:player/sp/percentage
#基本採掘速度1上昇
scoreboard players add @s MiningSpeed 1
#職業スキルを覚える

#白刃騎士
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/203
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"空脚【エアステップ】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"斬撃の衝撃を利用して前方へ跳躍する間合い操作技。（SP10消費）"}]}}]

#共鳴騎士
advancement grant @s[advancements={neoadvancement:neoskill/210=true}] only neoadvancement:neoskill/212
tellraw @s[advancements={neoadvancement:neoskill/210=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴縛鎖【レゾナンス・チェイン】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると周囲16m以内の最も近い敵を拘束し大ダメージを与える。範囲内の刻印持ちの敵には追加ダメージを与える。(SP20消費）"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/210=true}] only neoadvancement:neoskill/213
tellraw @s[advancements={neoadvancement:neoskill/210=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴跳躍【レゾナンス・リープ】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると周囲16m以内の最も遠い共鳴刻印持ちにテレポートし、大ダメージを与える。範囲内の刻印持ちの敵には追加ダメージを与える。（SP20消費）"}]}}]

# 暗殺士官
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/253
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"深蝕苦無【ディーブヴェノム】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時8m以内の対象3体に小ダメージを与え継続する蝕む毒を与えるクナイを投げる（SP5消費）"}]}}]

# 演出
function neofunction:asset/particle/.levelup

# ステータス変動
function neofunction:player/attribute/lvl/10
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
