# 命名：20
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/admin/20


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 20
effect give @s minecraft:instant_health 1 26 true

# 基本採掘速度1上昇
scoreboard players add @s MiningSpeed 1

function neofunction:player/sp/percentage

#職業スキルを覚える
# 白刃騎士
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/204
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"剛刃草薙【スマッシャー】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"横薙ぎの衝撃波で周囲の敵を打ち上げる突破技。（SP30消費）"}]}}]

# 共鳴騎士
execute as @s[scores={LVL=19}] run advancement grant @s only neoadvancement:neoskill/218
execute as @s[scores={LVL=19}] run tellraw @s [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴短律【レゾナンス・カデンツァ】【レゾナンス・クリエイト】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると周囲8m以内のプレイヤーに共鳴短律を1分間付与する。共鳴短律は効果がある間スキルのCT減少速度が倍になる。（SP30消費）"}]}}]

# 演出
function neofunction:asset/particle/.levelup

# ステータス変動
function neofunction:player/attribute/lvl/20
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
