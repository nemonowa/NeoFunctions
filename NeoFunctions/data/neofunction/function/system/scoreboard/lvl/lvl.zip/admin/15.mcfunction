# 命名：15
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/admin/15


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 15
effect give @s minecraft:instant_health 1 26 true
function neofunction:player/sp/percentage

#  職業スキルを覚える

# 白刃騎士
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/208
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"陽動偏向【デコイ】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"敵の注意を引き寄せ攻撃を引き受ける挑発技能。（SP10消費）"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/205
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"反応回復【リアクティブ・ヒール】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"受けた痛みを糧に回復する前線維持スキル。（SP10消費）"}]}}]

# 共鳴騎士
advancement grant @s[advancements={neoadvancement:neoskill/210=true}] only neoadvancement:neoskill/215
tellraw @s[advancements={neoadvancement:neoskill/210=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴旋律【レゾナンス・メロディ】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると周囲16m以内共鳴刻印持ちの数に応じて、回復する。刻印持ちが多ければ多いほど回復効果が多くなる。（SP20消費）"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/210=true}] only neoadvancement:neoskill/216
tellraw @s[advancements={neoadvancement:neoskill/210=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴回帰【レゾナンス・リカバリー】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると自身に共鳴回帰を3分間付与する。共鳴回帰は周囲16mにいる刻印持ちの数に応じてSPの追加の回復効果を得る。（SP20消費）"}]}}]

# 暗殺士官
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/255
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"虚影潜伏【ヴォイド・ハイド】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、自身に透明化と再生能力を付与する。この効果は被弾すると解除される。（SP20消費）このスキルを取得しているとパッシブ効果を発動時再生能力を獲得できる。"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/256
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"幻脚【ファントム・ステップ】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、自身に移動速度上昇と跳躍力上昇を付与する。（SP20消費）"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/258
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"影潜【シャドウ・ディセント】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、周囲16mの敵対状態を解除し、1秒間敵対しなくなる。（SP10消費）"}]}}]


# 演出
function neofunction:asset/particle/.levelup

# ステータス変動
function neofunction:player/attribute/lvl/15
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
