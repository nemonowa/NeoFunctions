# 命名：40
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/admin/40


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 40
effect give @s minecraft:instant_health 1 26 true

# 基本採掘速度1上昇
scoreboard players add @s MiningSpeed 1

function neofunction:player/sp/percentage

# 演出
function neofunction:asset/particle/.levelup

#職業スキルを覚える
#白刃騎士
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/209
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"天地断裂【グランドクロス】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"天地を断つ究極の一撃。周囲に壊滅的ダメージ。（SP100消費）"}]}}]

#共鳴騎士
advancement grant @s only neoadvancement:neoskill/211
tellraw @s [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴領域【レゾナンス・サンクチュアリ】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると1分間の共鳴領域を生成する。共鳴領域は範囲内のあらゆる敵に1秒ごとに鈍足とウィザー、共鳴刻印を与え、範囲内のプレイヤーには共鳴回帰、共鳴短律を付与する。"}]}}]

# 暗殺士官
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/259
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"終影審判【エンド・オブ・シャドウ】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、周囲16mの敵に対し0.1秒ごとに敵の背後を取り、致命的な連撃をお見舞いする。影の鉄槌を下すAssasinの奥義(SP100消費）"}]}}]


# ステータス変動
function neofunction:player/attribute/lvl/40
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
