# 命名：5
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/5


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 5
effect give @s minecraft:instant_health 1 26 true
function neofunction:player/sp/percentage

#職業スキルを覚える
#白刃騎士
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/202
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"白刃一閃【スラッシュ】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"神速の踏み込みから放たれる斬撃。武器破壊の可能性あり。反動で一時行動不能。（SP20消費）"}]}}]
#共鳴騎士
advancement grant @s[advancements={neoadvancement:neoskill/210=true}] only neoadvancement:neoskill/214
tellraw @s[advancements={neoadvancement:neoskill/210=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴刻印【レゾナンス・シギル】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"殴った相手に共鳴刻印を付与する。トリガーすると周囲3m以内の敵に共鳴刻印を付与する。30秒間のウィザーを付与する。（SP10消費）"}]}}]

# 医工士官
advancement grant @s[advancements={neoadvancement:neoskill/240=true}] only neoadvancement:neoskill/242
tellraw @s[advancements={neoadvancement:neoskill/240=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"劇薬強襲【トキシックレイド】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"命中させた敵に劇薬入りの猛毒を撃ち込み、じわじわとウィザー(衰弱)で蝕む単体攻撃。LVLが上がるほど衰弱の深さと持続時間が増していく。（SP6消費）"}]}}]

# 暗殺士官
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/252
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"影打ち【シャドウ・ストライク】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、自身を標的と認識していない敵に対し、致命的な一撃を与える（SP20消費）"}]}}]


# 演出
function neofunction:asset/particle/.levelup

# ステータス変動
function neofunction:player/attribute/lvl/5
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
