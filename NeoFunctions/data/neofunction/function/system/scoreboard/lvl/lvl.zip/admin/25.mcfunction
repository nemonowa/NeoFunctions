# 命名：25
# 説明：レベルアップ時の処理
# >/function neofunction:system/scoreboard/lvl
# =/function neofunction:system/scoreboard/lvl/admin/25


# 内容
execute if score levelStatsSync temp matches -1 run function neofunction:system/levelstatssync/load
scoreboard players set @s LVL 25
effect give @s minecraft:instant_health 1 26 true
function neofunction:player/sp/percentage

# 白刃士官
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/206
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"鋼刃結界【スチール・ドミニオン】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"周囲の味方に攻撃力上昇と耐性を付与。（SP30消費）"}]}}]
advancement grant @s[advancements={neoadvancement:neoskill/200=true}] only neoadvancement:neoskill/207
tellraw @s[advancements={neoadvancement:neoskill/200=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true},{"text":"不動【フォートレス】","color":"white","bold":true,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"ノックバック無効を2分付与。再使用で時間リセット。（SP30消費）"}]}}]

# 共鳴士官
advancement grant @s only neoadvancement:neoskill/217
tellraw @s [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"共鳴回帰【レゾナンス・リカージョン】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"トリガーすると自身の装備の耐久値を全回復する。（SP100消費）"}]}}]

# 暗殺士官
advancement grant @s[advancements={neoadvancement:neoskill/250=true}] only neoadvancement:neoskill/257
tellraw @s[advancements={neoadvancement:neoskill/250=true}] [{"text":"新スキル獲得:","color":"dark_aqua","bold":true,"italic":false},{"text":"影杭【シャドウ・ピラー】","color":"white","bold":true,"italic":false,"underlined":true,"hoverEvent":{"action":"show_text","value":[{"text":"発動時、自身の位置に影の杭を打ち込む、影の杭はその周辺にいる敵に弱体化と鈍足エフェクトを与える(SP20消費）"}]}}]


# 演出
function neofunction:asset/particle/.levelup

# ステータス変動
function neofunction:player/attribute/lvl/25
# レベル同期(Level Sync)
function neofunction:system/levelstatssync/on_level_up
