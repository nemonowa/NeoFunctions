# 命名：45
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/45

# 内容：ステータス調整
scoreboard players set @s SPmax 190
attribute @s minecraft:generic.attack_damage base set 5.5
attribute @s minecraft:generic.max_health base set 38
attribute @s minecraft:generic.max_absorption base set 15.2