# 命名：12
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/12

# 内容：ステータス調整
scoreboard players set @s SPmax 124
attribute @s minecraft:generic.attack_damage base set 2.2
attribute @s minecraft:generic.max_health base set 24.8
attribute @s minecraft:generic.max_absorption base set 9.92