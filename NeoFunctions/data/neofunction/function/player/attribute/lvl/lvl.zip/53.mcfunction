# 命名：53
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/53

# 内容：ステータス調整
scoreboard players set @s SPmax 206
attribute @s minecraft:generic.attack_damage base set 6.3
attribute @s minecraft:generic.max_health base set 41.2
attribute @s minecraft:generic.max_absorption base set 16.48