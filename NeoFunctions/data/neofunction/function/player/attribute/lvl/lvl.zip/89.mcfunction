# 命名：89
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/89

# 内容：ステータス調整
scoreboard players set @s SPmax 278
attribute @s minecraft:generic.attack_damage base set 9.9
attribute @s minecraft:generic.max_health base set 55.6
attribute @s minecraft:generic.max_absorption base set 22.24