# 命名：99
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/99

# 内容：ステータス調整
scoreboard players set @s SPmax 298
attribute @s minecraft:generic.attack_damage base set 10.9
attribute @s minecraft:generic.max_health base set 59.6
attribute @s minecraft:generic.max_absorption base set 23.84