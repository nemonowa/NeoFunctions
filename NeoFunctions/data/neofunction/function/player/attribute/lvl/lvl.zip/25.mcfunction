# 命名：25
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/25

# 内容：ステータス調整
scoreboard players set @s SPmax 150
attribute @s minecraft:generic.attack_damage base set 3.5
attribute @s minecraft:generic.max_health base set 30
attribute @s minecraft:generic.max_absorption base set 12