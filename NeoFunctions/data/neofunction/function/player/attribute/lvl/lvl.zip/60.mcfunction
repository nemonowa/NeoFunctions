# 命名：60
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/60

# 内容：ステータス調整
scoreboard players set @s SPmax 220
attribute @s minecraft:generic.attack_damage base set 7
attribute @s minecraft:generic.max_health base set 44
attribute @s minecraft:generic.max_absorption base set 17.6