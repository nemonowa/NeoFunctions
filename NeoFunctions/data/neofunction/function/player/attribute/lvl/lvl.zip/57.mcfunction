# 命名：57
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/57

# 内容：ステータス調整
scoreboard players set @s SPmax 214
attribute @s minecraft:generic.attack_damage base set 6.7
attribute @s minecraft:generic.max_health base set 42.8
attribute @s minecraft:generic.max_absorption base set 17.12