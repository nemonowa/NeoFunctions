# 命名：64
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/64

# 内容：ステータス調整
scoreboard players set @s SPmax 228
attribute @s minecraft:generic.attack_damage base set 7.4
attribute @s minecraft:generic.max_health base set 45.6
attribute @s minecraft:generic.max_absorption base set 18.24