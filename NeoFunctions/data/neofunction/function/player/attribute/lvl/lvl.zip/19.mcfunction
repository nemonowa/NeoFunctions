# 命名：19
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/19

# 内容：ステータス調整
scoreboard players set @s SPmax 138
attribute @s minecraft:generic.attack_damage base set 2.9
attribute @s minecraft:generic.max_health base set 27.6
attribute @s minecraft:generic.max_absorption base set 11.04