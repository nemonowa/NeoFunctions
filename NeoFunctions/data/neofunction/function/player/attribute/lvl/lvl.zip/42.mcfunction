# 命名：42
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/42

# 内容：ステータス調整
scoreboard players set @s SPmax 184
attribute @s minecraft:generic.attack_damage base set 5.2
attribute @s minecraft:generic.max_health base set 36.8
attribute @s minecraft:generic.max_absorption base set 14.72