# 命名：17
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/17

# 内容：ステータス調整
scoreboard players set @s SPmax 134
attribute @s minecraft:generic.attack_damage base set 2.7
attribute @s minecraft:generic.max_health base set 26.8
attribute @s minecraft:generic.max_absorption base set 10.72