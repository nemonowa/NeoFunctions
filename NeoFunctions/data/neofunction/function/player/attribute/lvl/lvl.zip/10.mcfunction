# 命名：10
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/10

# 内容：ステータス調整
scoreboard players set @s SPmax 120
attribute @s minecraft:generic.attack_damage base set 2
attribute @s minecraft:generic.max_health base set 24
attribute @s minecraft:generic.max_absorption base set 9.6