# 命名：4
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/4

# 内容：ステータス調整
scoreboard players set @s SPmax 108
attribute @s minecraft:generic.attack_damage base set 1.4
attribute @s minecraft:generic.max_health base set 21.6
attribute @s minecraft:generic.max_absorption base set 8.64