# 命名：8
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/8

# 内容：ステータス調整
scoreboard players set @s SPmax 116
attribute @s minecraft:generic.attack_damage base set 1.8
attribute @s minecraft:generic.max_health base set 23.2
attribute @s minecraft:generic.max_absorption base set 9.28