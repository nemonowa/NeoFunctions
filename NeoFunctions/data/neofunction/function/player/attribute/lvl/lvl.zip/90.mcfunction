# 命名：90
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/90

# 内容：ステータス調整
scoreboard players set @s SPmax 280
attribute @s minecraft:generic.attack_damage base set 10
attribute @s minecraft:generic.max_health base set 56
attribute @s minecraft:generic.max_absorption base set 22.4