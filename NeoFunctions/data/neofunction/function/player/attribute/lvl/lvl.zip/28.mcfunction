# 命名：28
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/28

# 内容：ステータス調整
scoreboard players set @s SPmax 156
attribute @s minecraft:generic.attack_damage base set 3.8
attribute @s minecraft:generic.max_health base set 31.2
attribute @s minecraft:generic.max_absorption base set 12.48