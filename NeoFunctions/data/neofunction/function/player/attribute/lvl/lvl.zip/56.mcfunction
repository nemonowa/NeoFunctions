# 命名：56
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/56

# 内容：ステータス調整
scoreboard players set @s SPmax 212
attribute @s minecraft:generic.attack_damage base set 6.6
attribute @s minecraft:generic.max_health base set 42.4
attribute @s minecraft:generic.max_absorption base set 16.96