# 命名：75
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/75

# 内容：ステータス調整
scoreboard players set @s SPmax 250
attribute @s minecraft:generic.attack_damage base set 8.5
attribute @s minecraft:generic.max_health base set 50
attribute @s minecraft:generic.max_absorption base set 20