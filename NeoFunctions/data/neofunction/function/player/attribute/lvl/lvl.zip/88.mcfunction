# 命名：88
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/88

# 内容：ステータス調整
scoreboard players set @s SPmax 276
attribute @s minecraft:generic.attack_damage base set 9.8
attribute @s minecraft:generic.max_health base set 55.2
attribute @s minecraft:generic.max_absorption base set 22.08