# 命名：43
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/43

# 内容：ステータス調整
scoreboard players set @s SPmax 186
attribute @s minecraft:generic.attack_damage base set 5.3
attribute @s minecraft:generic.max_health base set 37.2
attribute @s minecraft:generic.max_absorption base set 14.88