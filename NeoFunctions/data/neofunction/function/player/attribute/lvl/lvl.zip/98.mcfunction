# 命名：98
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/98

# 内容：ステータス調整
scoreboard players set @s SPmax 296
attribute @s minecraft:generic.attack_damage base set 10.8
attribute @s minecraft:generic.max_health base set 59.2
attribute @s minecraft:generic.max_absorption base set 23.68