# 命名：52
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/52

# 内容：ステータス調整
scoreboard players set @s SPmax 204
attribute @s minecraft:generic.attack_damage base set 6.2
attribute @s minecraft:generic.max_health base set 40.8
attribute @s minecraft:generic.max_absorption base set 16.32