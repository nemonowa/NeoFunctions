# 命名：40
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/40

# 内容：ステータス調整
scoreboard players set @s SPmax 180
attribute @s minecraft:generic.attack_damage base set 5
attribute @s minecraft:generic.max_health base set 36
attribute @s minecraft:generic.max_absorption base set 14.4