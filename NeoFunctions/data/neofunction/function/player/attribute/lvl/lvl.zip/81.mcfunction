# 命名：81
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/81

# 内容：ステータス調整
scoreboard players set @s SPmax 262
attribute @s minecraft:generic.attack_damage base set 9.1
attribute @s minecraft:generic.max_health base set 52.4
attribute @s minecraft:generic.max_absorption base set 20.96