# 命名：30
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/30

# 内容：ステータス調整
scoreboard players set @s SPmax 160
attribute @s minecraft:generic.attack_damage base set 4
attribute @s minecraft:generic.max_health base set 32
attribute @s minecraft:generic.max_absorption base set 12.8