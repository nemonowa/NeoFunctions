# 命名：38
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/38

# 内容：ステータス調整
scoreboard players set @s SPmax 176
attribute @s minecraft:generic.attack_damage base set 4.8
attribute @s minecraft:generic.max_health base set 35.2
attribute @s minecraft:generic.max_absorption base set 14.08