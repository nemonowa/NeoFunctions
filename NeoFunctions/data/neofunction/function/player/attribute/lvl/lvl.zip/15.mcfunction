# 命名：15
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/15

# 内容：ステータス調整
scoreboard players set @s SPmax 130
attribute @s minecraft:generic.attack_damage base set 2.5
attribute @s minecraft:generic.max_health base set 26
attribute @s minecraft:generic.max_absorption base set 10.4