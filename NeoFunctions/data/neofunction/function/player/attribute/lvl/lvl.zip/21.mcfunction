# 命名：21
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/21

# 内容：ステータス調整
scoreboard players set @s SPmax 142
attribute @s minecraft:generic.attack_damage base set 3.1
attribute @s minecraft:generic.max_health base set 28.4
attribute @s minecraft:generic.max_absorption base set 11.36