# 命名：9
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/9

# 内容：ステータス調整
scoreboard players set @s SPmax 118
attribute @s minecraft:generic.attack_damage base set 1.9
attribute @s minecraft:generic.max_health base set 23.6
attribute @s minecraft:generic.max_absorption base set 9.44