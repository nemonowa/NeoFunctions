# 命名：29
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/29

# 内容：ステータス調整
scoreboard players set @s SPmax 158
attribute @s minecraft:generic.attack_damage base set 3.9
attribute @s minecraft:generic.max_health base set 31.6
attribute @s minecraft:generic.max_absorption base set 12.64