# 命名：27
# 説明：レベルに伴う経験値上昇
# >/function neofunction:player/attribute/load
# =/function neofunction:player/attribute/lvl/27

# 内容：ステータス調整
scoreboard players set @s SPmax 154
attribute @s minecraft:generic.attack_damage base set 3.7
attribute @s minecraft:generic.max_health base set 30.8
attribute @s minecraft:generic.max_absorption base set 12.32