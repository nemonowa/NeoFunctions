# 命名：0
# 説明：補正用デフォルトステータスvanilla
# >
# =/function neofunction:player/attribute/lvl/0


## 内容
scoreboard players set @s SPmax 100
attribute @s minecraft:generic.armor base set 0
attribute @s minecraft:generic.armor_toughness base set 0
attribute @s minecraft:generic.attack_damage base set 1
attribute @s minecraft:generic.knockback_resistance base set 0
attribute @s minecraft:generic.attack_speed base set 4
attribute @s minecraft:generic.luck base set 0
attribute @s minecraft:generic.max_absorption base set 0
attribute @s minecraft:generic.max_health base set 20
attribute @s minecraft:generic.movement_speed base set 0.1

