# 命名：grant_root
# 説明：rootの進捗を自動付与（1回だけ通る）
# >
# =/function neoadvancement:enchantdescription/init/grant_root
advancement grant @s only neoadvancement:enchantdescription/root
