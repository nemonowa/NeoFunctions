# 命名：thorns
# 説明：Thorns ≪棘の鎧≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/thorns
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/thorns
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Thorns ≪棘の鎧≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "反撃の発動確率が1レベルごとに+15%増加するが、Lv.7で上限の100%（必ず発動）に到達し、それ以上レベルを上げても変化しない。反射ダメージの量自体はレベルに関係なく一定。（防具専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
