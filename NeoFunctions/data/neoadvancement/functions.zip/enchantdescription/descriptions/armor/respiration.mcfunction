# 命名：respiration
# 説明：Respiration ≪水中呼吸≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/respiration
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/respiration
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Respiration ≪水中呼吸≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "水中で息が続く時間が1レベルごとに約15秒延長する（上限なし）。溺れダメージを防げる確率は「レベル÷(レベル+1)」で決まり、レベルを上げるほど100%に近づくが理論上100%には到達しない（Lv.10で約91%、Lv.30で約97%）。（ヘルメット専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
