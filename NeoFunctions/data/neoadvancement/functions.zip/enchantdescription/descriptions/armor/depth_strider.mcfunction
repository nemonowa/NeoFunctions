# 命名：depth_strider
# 説明：Depth Strider ≪水中歩行≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/depth_strider
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/depth_strider
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Depth Strider ≪水中歩行≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "水中移動速度が上がっていくが、Lv.3で陸上と同じ速さに到達するとそこで頭打ちになり、それ以上レベルを上げても速くならない。（ブーツ専用。氷渡りとは同時に付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
