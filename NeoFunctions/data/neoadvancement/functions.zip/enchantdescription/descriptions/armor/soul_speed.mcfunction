# 命名：soul_speed
# 説明：Soul Speed ≪ソウルスピード≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/soul_speed
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/soul_speed
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Soul Speed ≪ソウルスピード≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "ソウルサンド・ソウルソイル上での移動速度倍率が1レベルごとに+0.105増加する（Lv.1で約1.4倍、上限なし）。（ブーツ専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
