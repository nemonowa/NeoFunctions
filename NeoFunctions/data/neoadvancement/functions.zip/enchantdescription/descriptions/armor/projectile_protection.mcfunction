# 命名：projectile_protection
# 説明：Projectile Protection ≪飛び道具耐性≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/projectile_protection
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/projectile_protection
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Projectile Protection ≪飛び道具耐性≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "矢などの飛び道具ダメージを防具1枚あたりレベル×8%軽減する。他の耐性系エンチャントと合算した装備全体の軽減率には80%の上限があり、単体でもLv.10で上限に到達する。（防具専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
