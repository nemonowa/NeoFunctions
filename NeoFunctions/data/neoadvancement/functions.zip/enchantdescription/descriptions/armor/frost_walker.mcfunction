# 命名：frost_walker
# 説明：Frost Walker ≪氷渡り≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/frost_walker
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/frost_walker
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Frost Walker ≪氷渡り≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "足元が凍る範囲の半径が1レベルごとに+1ブロック広がる（Lv.1で半径3）。レベルが上がるほど凍らせられる範囲がどんどん広くなる。（ブーツ専用。水中歩行とは同時に付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
