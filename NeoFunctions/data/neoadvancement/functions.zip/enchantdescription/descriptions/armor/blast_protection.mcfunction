# 命名：blast_protection
# 説明：Blast Protection ≪爆発耐性≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/blast_protection
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/blast_protection
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Blast Protection ≪爆発耐性≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "爆発ダメージを防具1枚あたりレベル×8%軽減する。他の耐性系エンチャントと合算した装備全体の軽減率には80%の上限があり、単体でもLv.10で上限に到達する（それ以上レベルを上げてもダメージ軽減自体は増えない）。爆発によるノックバックも、レベルが上がるほど軽減されていく。（防具専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
