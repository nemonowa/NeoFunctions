# 命名：fire_protection
# 説明：Fire Protection ≪火炎耐性≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/fire_protection
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/fire_protection
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Fire Protection ≪火炎耐性≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "火・溶岩ダメージを防具1枚あたりレベル×8%軽減する。他の耐性系エンチャントと合算した装備全体の軽減率には80%の上限があり、単体でもLv.10で上限に到達する。燃焼時間の短縮にも頭打ちがあり、装備合計7レベル分（単体ならLv.7）で燃焼時間はゼロになる。（防具専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
