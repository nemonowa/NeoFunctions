# 命名：protection
# 説明：Protection ≪ダメージ軽減≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/protection
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/protection
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Protection ≪ダメージ軽減≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "あらゆるダメージを防具1枚あたりレベル×4%軽減する。ただし他の耐性系エンチャント（火炎/爆発/飛び道具耐性）と合算した装備全体の軽減率には80%の上限があり、Protectionだけでも防具1枚にLv.20を付ければ単体で上限に到達する（それ以上レベルを上げても軽減率は増えない）。（防具専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
