# 命名：feather_falling
# 説明：Feather Falling ≪落下耐性≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/feather_falling
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/feather_falling
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Feather Falling ≪落下耐性≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "落下ダメージを防具1枚あたりレベル×12%軽減する。他の耐性系エンチャント（Protectionも含む）と合算した装備全体の軽減率には80%の上限があり、単体でもLv.7で上限に近づく（Lv.4単体では48%、上限まではまだ余裕がある）。エリトラ滑空中の衝突ダメージには効果なし。（ブーツ専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
