# 命名：swift_sneak
# 説明：Swift Sneak ≪スニーク速度上昇≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/swift_sneak
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/swift_sneak
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Swift Sneak ≪スニーク速度上昇≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "スニーク移動速度が通常歩行速度の1レベルごとに+15%ずつ近づく。Lv.3で通常歩行速度の75%相当に到達するのがバニラ確認範囲で、それ以上のレベルでの検証データはなし。（レギンス専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
