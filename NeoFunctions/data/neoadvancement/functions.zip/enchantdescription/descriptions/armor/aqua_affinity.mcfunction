# 命名：aqua_affinity
# 説明：Aqua Affinity ≪水中採掘≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/armor/aqua_affinity
# >
# =/function neoadvancement:enchantdescription/descriptions/armor/aqua_affinity
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Aqua Affinity ≪水中採掘≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。（ヘルメット専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
