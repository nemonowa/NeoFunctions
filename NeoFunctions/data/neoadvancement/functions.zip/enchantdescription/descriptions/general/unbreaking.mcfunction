# 命名：unbreaking
# 説明：Unbreaking ≪耐久力≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/general/unbreaking
# >
# =/function neoadvancement:enchantdescription/descriptions/general/unbreaking
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Unbreaking ≪耐久力≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "耐久値が減らない確率が上がる。道具・武器は「レベル÷(レベル+1)」で決まり、レベルを上げるほど100%に近づくが理論上100%には到達しない（Lv.10で約91%、Lv.30で約97%）。防具は式が異なり「40×レベル÷(レベル+1)%」で、こちらはどれだけレベルを上げても40%が実質の上限（Lv.10で約36%、Lv.30で約39%、絶対に40%を超えない）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
