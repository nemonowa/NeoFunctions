# 命名：mending
# 説明：Mending ≪修繕≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/general/mending
# >
# =/function neoadvancement:enchantdescription/descriptions/general/mending
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Mending ≪修繕≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果、経験値1につき耐久値2回復）。ただしマイナス経験値を受け取った場合は同じ比率が逆方向に働き、経験値1につき耐久値2ずつ失われてしまうので注意。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
