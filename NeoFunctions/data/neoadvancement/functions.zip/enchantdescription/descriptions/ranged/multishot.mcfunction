# 命名：multishot
# 説明：Multishot ≪拡散≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/multishot
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/multishot
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Multishot ≪拡散≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果、常に3本発射）。（クロスボウ専用。弓には付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
