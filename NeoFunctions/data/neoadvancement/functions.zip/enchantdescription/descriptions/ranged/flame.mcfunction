# 命名：flame
# 説明：Flame ≪フレイム≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/flame
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/flame
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Flame ≪フレイム≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。（弓専用。クロスボウには付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
