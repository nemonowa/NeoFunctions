# 命名：power
# 説明：Power ≪射撃ダメージ増加≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/power
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/power
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Power ≪射撃ダメージ増加≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "矢のダメージが1レベルごとに+25%増加する（上限なし）。（弓専用。クロスボウには付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
