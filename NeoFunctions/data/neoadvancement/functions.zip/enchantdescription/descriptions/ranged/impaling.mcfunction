# 命名：impaling
# 説明：Impaling ≪水生特効≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/impaling
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/impaling
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Impaling ≪水生特効≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "水生Mobへのダメージが1レベルごとに+2.5増加する（上限なし）。（トライデント専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
