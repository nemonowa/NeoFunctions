# 命名：infinity
# 説明：Infinity ≪無限≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/infinity
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/infinity
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Infinity ≪無限≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。（弓専用。クロスボウには付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
