# 命名：piercing
# 説明：Piercing ≪貫通≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/piercing
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/piercing
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Piercing ≪貫通≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "矢が貫通できる敵の数が1レベルごとに+1体増加する（上限なし）。（クロスボウ専用。弓には付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
