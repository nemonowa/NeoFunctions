# 命名：channeling
# 説明：Channeling ≪召雷≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/channeling
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/channeling
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Channeling ≪召雷≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。（トライデント専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
