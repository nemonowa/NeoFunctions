# 命名：loyalty
# 説明：Loyalty ≪忠誠≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/loyalty
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/loyalty
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Loyalty ≪忠誠≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "投げたトライデントが手元に戻ってくる速度が、レベルが高いほど速くなる。（トライデント専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
