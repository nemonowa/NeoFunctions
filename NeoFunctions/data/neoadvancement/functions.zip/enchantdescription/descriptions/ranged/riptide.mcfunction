# 命名：riptide
# 説明：Riptide ≪激流≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/riptide
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/riptide
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Riptide ≪激流≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "水中や雨天時にトライデントを投げたときの突進の飛距離が、レベルが高いほど伸びる。（トライデント専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
