# 命名：punch
# 説明：Punch ≪パンチ≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/punch
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/punch
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Punch ≪パンチ≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "矢が命中した相手のノックバックが、レベルが高いほど強くなる（吹き飛ぶ距離が伸びる）。（弓専用。クロスボウには付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
