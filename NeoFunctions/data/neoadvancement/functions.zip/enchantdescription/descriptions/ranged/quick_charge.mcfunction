# 命名：quick_charge
# 説明：Quick Charge ≪高速装填≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/ranged/quick_charge
# >
# =/function neoadvancement:enchantdescription/descriptions/ranged/quick_charge
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Quick Charge ≪高速装填≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "クロスボウの装填時間が1レベルごとに0.25秒短縮する。ただし装填時間は0秒未満にはならないため、Lv.5（基本1.25秒÷0.25秒）で完全に頭打ちになる。（クロスボウ専用。弓には付けられない）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
