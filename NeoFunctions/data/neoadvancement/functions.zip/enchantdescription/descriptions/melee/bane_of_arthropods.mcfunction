# 命名：bane_of_arthropods
# 説明：Bane of Arthropods ≪虫特効≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/bane_of_arthropods
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/bane_of_arthropods
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Bane of Arthropods ≪虫特効≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "節足動物系Mobへのダメージが1レベルごとに+2.5増加する（上限なし）。命中時に付与するスロウ効果の持続時間も伸びるが、こちらは緩やかにしか伸びない。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
