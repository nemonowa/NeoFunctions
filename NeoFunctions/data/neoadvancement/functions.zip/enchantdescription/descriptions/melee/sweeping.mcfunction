# 命名：sweeping
# 説明：Sweeping Edge ≪範囲ダメージ増加≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/sweeping
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/sweeping
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Sweeping Edge ≪範囲ダメージ増加≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "薙ぎ払い攻撃で周囲に入るダメージが、レベルを上げるほど本来の攻撃力に近づいていく（Lv.1で約半分、Lv.3で約75%、Lv.30でも約97%）。ただし理論上100%には到達しない、伸びが徐々に緩やかになる特殊な増え方。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
