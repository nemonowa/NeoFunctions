# 命名：smite
# 説明：Smite ≪アンデッド特効≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/smite
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/smite
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Smite ≪アンデッド特効≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "アンデッド系Mobへのダメージが1レベルごとに+2.5増加する。上限はなく伸び続ける。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
