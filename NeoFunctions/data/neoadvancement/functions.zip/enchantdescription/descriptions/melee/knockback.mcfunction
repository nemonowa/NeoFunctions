# 命名：knockback
# 説明：Knockback ≪ノックバック≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/knockback
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/knockback
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Knockback ≪ノックバック≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "殴った相手のノックバックが、レベルが高いほど強くなる（吹き飛ぶ距離が伸びる）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
