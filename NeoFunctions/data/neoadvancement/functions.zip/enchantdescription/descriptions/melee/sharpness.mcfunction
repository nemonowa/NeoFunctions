# 命名：sharpness
# 説明：Sharpness ≪ダメージ増加≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/sharpness
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/sharpness
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Sharpness ≪ダメージ増加≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "近接ダメージが1レベルごとに+0.5増加する（Lv.1で+1）。上限はなく、レベルを上げた分だけ伸び続ける。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
