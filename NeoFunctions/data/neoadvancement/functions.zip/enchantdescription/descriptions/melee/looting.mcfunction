# 命名：looting
# 説明：Looting ≪ドロップ増加≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/looting
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/looting
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Looting ≪ドロップ増加≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "Mob討伐時の最大ドロップ数が1レベルごとに+1個、レアドロップ確率が+1%増加する（上限なし）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
