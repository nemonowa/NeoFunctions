# 命名：fire_aspect
# 説明：Fire Aspect ≪火属性≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/melee/fire_aspect
# >
# =/function neoadvancement:enchantdescription/descriptions/melee/fire_aspect
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Fire Aspect ≪火属性≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "攻撃が命中した相手の燃焼時間が1レベルごとに+4秒増加する（上限なし。高レベルだと長時間燃え続ける）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
