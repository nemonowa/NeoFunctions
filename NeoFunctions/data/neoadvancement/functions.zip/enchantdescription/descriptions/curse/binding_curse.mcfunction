# 命名：binding_curse
# 説明：束縛の呪い -Curse of Binding- 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/curse/binding_curse
# >
# =/function neoadvancement:enchantdescription/descriptions/curse/binding_curse
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "束縛の呪い -Curse of Binding- ", "color": "red", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
