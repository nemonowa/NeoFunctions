# 命名：silk_touch
# 説明：Silk Touch ≪シルクタッチ≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/tool/silk_touch
# >
# =/function neoadvancement:enchantdescription/descriptions/tool/silk_touch
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Silk Touch ≪シルクタッチ≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "レベルによる変化なし（固定効果）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
