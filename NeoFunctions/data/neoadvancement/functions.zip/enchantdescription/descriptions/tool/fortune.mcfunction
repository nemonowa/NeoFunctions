# 命名：fortune
# 説明：Fortune ≪幸運≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/tool/fortune
# >
# =/function neoadvancement:enchantdescription/descriptions/tool/fortune
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Fortune ≪幸運≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "ドロップ数を増やす。「2÷(レベル+2)の確率で追加ドロップなし、それ以外は2個〜(レベル+1)個の範囲でランダムに追加ドロップが上乗せされる」という仕組みで、レベルが上がるほど追加ドロップなしになる確率が下がり、増える量の振れ幅も大きくなる（上限なく伸び続ける）。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
