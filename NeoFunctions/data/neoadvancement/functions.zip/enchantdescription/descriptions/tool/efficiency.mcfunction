# 命名：efficiency
# 説明：Efficiency ≪効率強化≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/tool/efficiency
# >
# =/function neoadvancement:enchantdescription/descriptions/tool/efficiency
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Efficiency ≪効率強化≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "採掘速度への加算値は「レベルの2乗+1」という特殊な伸び方をする（一定量ずつ増えるのではなく、レベルが上がるほど加速度的に増える）。目安はLv.1で+2、Lv.5で+26、Lv.10で+101、Lv.20で+401。％で見た伸び幅は道具の基礎速度によっても変わる。", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
