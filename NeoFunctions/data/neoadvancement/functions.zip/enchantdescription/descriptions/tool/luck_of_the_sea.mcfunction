# 命名：luck_of_the_sea
# 説明：Luck of the Sea ≪宝釣り≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/tool/luck_of_the_sea
# >
# =/function neoadvancement:enchantdescription/descriptions/tool/luck_of_the_sea
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Luck of the Sea ≪宝釣り≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "釣りで「宝」が釣れる確率がレベルが高いほど上がり、「ガラクタ」が釣れる確率はレベルが高いほど下がる。（釣り竿専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
