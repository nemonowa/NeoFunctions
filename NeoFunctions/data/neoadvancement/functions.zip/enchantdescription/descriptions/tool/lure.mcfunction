# 命名：lure
# 説明：Lure ≪入れ食い≫ 入手通知
# 説明：source advancement: neoadvancement:enchantdescription/tool/lure
# >
# =/function neoadvancement:enchantdescription/descriptions/tool/lure
tellraw @s ["", {"text": "✦ NEW! ", "color": "yellow", "bold": true}, {"text": "Lure ≪入れ食い≫ ", "color": "aqua", "bold": true, "hoverEvent": {"action": "show_text", "value": [{"text": "魚がかかるまでの待ち時間が、レベルが高いほど短くなる。（釣り竿専用）", "color": "white"}]}}, {"text": "を入手した！", "color": "white"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1.0 1.2
